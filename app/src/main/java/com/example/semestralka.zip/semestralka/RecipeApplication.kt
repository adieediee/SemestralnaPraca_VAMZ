package com.example.semestralka
import RecipeDatabase
import android.app.Application
import com.example.sem_nova.Data.AppContainer
import com.example.sem_nova.Data.AppDataContainer


import com.example.semestralka.database.RecipeRepository

class RecipeApplication : Application() {

    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppDataContainer(this)
    }
}
