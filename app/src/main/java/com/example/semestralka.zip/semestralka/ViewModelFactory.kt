import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.semestralka.RecipeApplication
import com.example.semestralka.database.RecipeRepository

object ViewModelFactory{
    val Factory = viewModelFactory {

        initializer {
            AddRecipeViewModel(
                inventoryApplication().container.recipeRepository
            )
        }
    }
}
fun CreationExtras.inventoryApplication(): RecipeApplication =
    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as RecipeApplication)