package com.example.semestralka.database

import androidx.annotation.WorkerThread
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withTimeoutOrNull

class RecipeRepository (
    private val recipeDao: RecipeDao
) {
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun upsertRecipe(recipe: Recipe) {
        recipeDao.upsertRecipe(recipe)
    }
    val allRecipes: Flow<List<Recipe>> = recipeDao.getAllRecipes()

}