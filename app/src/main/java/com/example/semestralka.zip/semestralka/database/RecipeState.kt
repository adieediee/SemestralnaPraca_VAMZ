package com.example.semestralka.database

data class RecipeState(
    val recipes: List<Recipe> = emptyList(),
    val name: String = "",
    val time: String = "",
    val servings: String ="",
    val type: String ="",
    val ingredients: List<String> = emptyList(),
    val method: String ="",
)
