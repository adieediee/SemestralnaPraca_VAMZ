import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.semestralka.database.Recipe
import com.example.semestralka.database.RecipeRepository
import kotlinx.coroutines.launch


class AddRecipeViewModel(private val dataRepository: RecipeRepository) : ViewModel() {

    // Mutable state to hold recipe details
    var recipeDetails = mutableStateOf(
        Recipe(
        name = "",
        time = "",
        servings = "",
        type = "",
        ingredients = "",
        method = ""
    )
    )
        private set

    // LiveData to observe the list of recipes
    private val _recipes = dataRepository.allRecipes.asLiveData()
    val recipes: LiveData<List<Recipe>> get() = _recipes

    // Function to update recipe details
    fun updateRecipeDetails(updatedRecipe: Recipe) {
        recipeDetails.value = updatedRecipe
    }

    // Function to save the recipe
    fun saveRecipe() {
        viewModelScope.launch {
            dataRepository.upsertRecipe(recipeDetails.value)
            // Optionally reset the form after saving
            recipeDetails.value = Recipe(
                name = "",
                time = "",
                servings = "",
                type = "",
                ingredients = "",
                method = ""
            )
        }
    }
}


