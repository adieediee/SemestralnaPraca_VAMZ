// RecipeViewModel.kt
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.semestralka.database.Recipe
import com.example.semestralka.database.RecipeRepository
import kotlinx.coroutines.launch

class RecipeViewModel(private val repository: RecipeRepository) : ViewModel() {

    private val _recipes = repository.allRecipes.asLiveData()
    val recipes: LiveData<List<Recipe>> get() = _recipes



    fun addRecipe(recipe: Recipe) {
        viewModelScope.launch {
            repository.upsertRecipe(recipe)
        }
    }
}

data class recipeDetails (
    val name: String = "",
    val time: String = "",
    val servings: String ="",
    val type: String ="",
    val ingredients: List<String> = emptyList(),
    val method: String ="",
    val id: Int = 0
)


