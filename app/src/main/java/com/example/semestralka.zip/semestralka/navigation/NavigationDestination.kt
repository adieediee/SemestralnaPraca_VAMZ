package com.example.semestralka.navigation

interface NavigationDestination {
    val route: String
}