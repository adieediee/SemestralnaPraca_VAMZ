package com.example.semestralka.database

import com.example.semestralka.R

 val DEFAULT_IMAGE_PATH = R.drawable.default_image_recipe